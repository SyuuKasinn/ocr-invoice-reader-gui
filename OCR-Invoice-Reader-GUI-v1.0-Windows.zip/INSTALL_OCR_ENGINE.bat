@echo off
REM Quick installation script for OCR Engine
REM Run this before using the GUI for the first time

echo ============================================
echo   OCR Invoice Reader - Engine Installation
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.8+ from:
    echo https://www.python.org/downloads/
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

echo Python found:
python --version
echo.

echo Installing OCR Engine...
echo This will download ~200MB of data on first run.
echo Please wait...
echo.

REM Install OCR engine
pip install git+https://github.com/SyuuKasinn/ocr-invoice-reader.git

if errorlevel 1 (
    echo.
    echo ERROR: Installation failed!
    echo.
    echo Troubleshooting:
    echo 1. Check internet connection
    echo 2. Update pip: python -m pip install --upgrade pip
    echo 3. Try again
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Installation Complete!
echo ============================================
echo.
echo The OCR engine is now installed.
echo You can run OCR-Invoice-Reader-GUI.exe
echo.
echo First-time use will download AI models (~200MB).
echo This is normal and only happens once.
echo.

pause
exit /b 0
