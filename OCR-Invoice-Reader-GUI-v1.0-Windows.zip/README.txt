OCR Invoice Reader GUI v1.0
=============================

Thank you for downloading OCR Invoice Reader GUI!

IMPORTANT: INSTALLATION REQUIRED
---------------------------------

This executable requires the OCR engine to function properly.

STEP 1: Install Python
-----------------------
Download and install Python 3.8 or higher from:
https://www.python.org/downloads/

During installation, check "Add Python to PATH"

STEP 2: Install OCR Engine
---------------------------
Open Command Prompt (cmd) and run:

    pip install git+https://github.com/SyuuKasinn/ocr-invoice-reader.git

This will install the OCR processing engine.
(First-time installation downloads ~200MB of AI models)

STEP 3: Run the Application
----------------------------
Double-click: OCR-Invoice-Reader-GUI.exe

USAGE
-----
1. Launch OCR-Invoice-Reader-GUI.exe
2. Drag and drop an invoice or waybill (PDF/JPG/PNG)
3. Select language (ch/en/japan/korean)
4. Click "Process Document"
5. View results in tabs:
   - Visualization: OCR boxes with colors
   - JSON: Structured data
   - Text: Extracted text
   - Tables: HTML tables

SYSTEM REQUIREMENTS
-------------------
- Windows 10/11 (64-bit)
- 4GB RAM minimum (8GB recommended)
- 500MB free disk space
- Internet connection (for first-time setup)

SUPPORTED LANGUAGES
-------------------
- Chinese (ch) - Recommended for mixed documents
- English (en)
- Japanese (japan)
- Korean (korean)

TROUBLESHOOTING
---------------

Q: "Command not found" error when processing
A: Install OCR engine: pip install git+https://github.com/SyuuKasinn/ocr-invoice-reader.git

Q: Slow first run
A: Normal. PaddleOCR downloads AI models (~200MB) on first use.

Q: Python not found
A: Reinstall Python and check "Add Python to PATH"

Q: tkinterdnd2 error
A: Run: pip install tkinterdnd2 Pillow

FEATURES
--------
- Multi-language OCR (Chinese/English/Japanese/Korean)
- Table detection and extraction
- Color-coded region visualization
- JSON structured output
- Batch processing support
- Multi-page PDF support

SAMPLE FILES
------------
Try the included sample-invoice.jpg to test the application.

SUPPORT & DOCUMENTATION
-----------------------
GitHub: https://github.com/SyuuKasinn/ocr-invoice-reader-gui
Issues: https://github.com/SyuuKasinn/ocr-invoice-reader-gui/issues
Main OCR Engine: https://github.com/SyuuKasinn/ocr-invoice-reader

LICENSE
-------
MIT License - Free to use for personal and commercial purposes

CREDITS
-------
- PaddleOCR: https://github.com/PaddlePaddle/PaddleOCR
- Developer: SyuuKasinn
- GUI Framework: Tkinter + TkinterDnD2

VERSION HISTORY
---------------
v1.0 (2026-05-13)
- Initial release
- Drag and drop interface
- Multi-tab results display
- 4 language support
- Cross-platform compatibility

=========================================
Enjoy using OCR Invoice Reader GUI!
=========================================
